import { createBrowserRouter } from 'react-router'
import { Login } from './components/Login'
import { DashboardLayout } from './components/DashboardLayout'
import { Dashboard } from './components/Dashboard'
import { Marketing } from './components/Marketing'
import { Settings } from './components/Settings'
import { Produtos } from './components/Produtos'
import { Pedidos } from './components/Pedidos'
import { Clientes } from './components/Clientes'
import { Relatorios } from './components/Relatorios'

export const router = createBrowserRouter([
  { path: '/', Component: Login },
  { path: '/login', Component: Login },
  {
    path: '/dashboard',
    Component: DashboardLayout,
    children: [
      { index: true, Component: Dashboard },
      { path: 'marketing', Component: Marketing },
      { path: 'produtos', Component: Produtos },
      { path: 'pedidos', Component: Pedidos },
      { path: 'clientes', Component: Clientes },
      { path: 'relatorios', Component: Relatorios },
      { path: 'settings', Component: Settings },
    ],
  },
])
